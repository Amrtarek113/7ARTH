import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api'; // Adjust port for app.py (8080)
const getToken = () => localStorage.getItem('token');

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add JWT token to requests for appx.py
api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const login = async (username, password) => {
  const response = await api.post('/login', { username, password });
  return response.data;
};

export const healthCheck = async () => {
  const response = await api.get('/health');
  return response.data;
};

export const predict = async (features) => {
  const response = await api.post('/predict', { features });
  return response.data;
};

export const getMetrics = async () => {
  const response = await api.get('/metrics');
  return response.data;
};

export const getRecentIncidents = async (scenario = '', page = 1, perPage = 10) => {
  const response = await api.get('/recent-incidents', {
    params: { scenario, page, per_page: perPage },
  });
  return response.data;
};

export const generateReport = async (scenario = '') => {
  const response = await api.get('/generate-report', {
    params: { scenario },
    responseType: 'blob', // For downloading files
  });
  return response;
};

// app.py-specific endpoints
export const getThreatLevel = async () => {
  const response = await api.get('/threat-level');
  return response.data;
};

export const getAttackTypes = async () => {
  const response = await api.get('/attack-types');
  return response.data;
};

export const getAttackOrigins = async () => {
  const response = await api.get('/attack-origins');
  return response.data;
};

export const getAttackCategories = async () => {
  const response = await api.get('/attack-categories');
  return response.data;
};

export const getScenarios = async () => {
  const response = await api.get('/scenarios');
  return response.data;
};