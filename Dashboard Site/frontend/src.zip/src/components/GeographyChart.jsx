import React from "react";
import { useTheme } from "@mui/material";
import { ResponsiveChoropleth } from "@nivo/geo";
import { geoFeatures } from "../data/mockGeoFeatures";
import { tokens } from "../theme";
import axios from "axios";

const GeographyChart = ({ isDashboard = false }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [metrics, setMetrics] = React.useState(null);

  // Fetch metrics from the backend
  React.useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const token = localStorage.getItem("token"); // Assume token is stored after login
        const response = await axios.get("/api/metrics", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setMetrics(response.data.data);
      } catch (error) {
        console.error("Error fetching metrics:", error);
      }
    };
    fetchMetrics();
  }, []);

  // Transform metrics into geography data
  const geographyData = React.useMemo(() => {
    if (!metrics) return []; // Return empty if no data
    return [
      { id: "USA", value: metrics.malicious_urls.current * 1000 }, // Scale for visualization
      { id: "UK", value: metrics.iot_attacks.current * 1000 },
      { id: "China", value: metrics.ransomware_incidents.current * 1000 },
      { id: "India", value: metrics.total_threats.current * 1000 },
    ];
  }, [metrics]);

  return (
    <ResponsiveChoropleth
      data={geographyData}
      theme={{
        axis: {
          domain: {
            line: {
              stroke: colors.grey[100],
            },
          },
          legend: {
            text: {
              fill: colors.grey[100],
            },
          },
          ticks: {
            line: {
              stroke: colors.grey[100],
              strokeWidth: 1,
            },
            text: {
              fill: colors.grey[100],
            },
          },
        },
        legends: {
          text: {
            fill: colors.grey[100],
          },
        },
      }}
      features={geoFeatures.features}
      margin={{ top: 0, right: 0, bottom: 0, left: 0 }}
      domain={[0, 4000]} // Adjusted domain based on scaled values
      unknownColor="#666666"
      label="properties.name"
      valueFormat=".2s"
      projectionScale={isDashboard ? 40 : 150}
      projectionTranslation={isDashboard ? [0.49, 0.6] : [0.5, 0.5]}
      projectionRotation={[0, 0, 0]}
      borderWidth={1.5}
      borderColor="#ffffff"
      legends={
        !isDashboard
          ? [
              {
                anchor: "bottom-left",
                direction: "column",
                justify: true,
                translateX: 20,
                translateY: -100,
                itemsSpacing: 0,
                itemWidth: 94,
                itemHeight: 18,
                itemDirection: "left-to-right",
                itemTextColor: colors.grey[100],
                itemOpacity: 0.85,
                symbolSize: 18,
                effects: [
                  {
                    on: "hover",
                    style: {
                      itemTextColor: "#ffffff",
                      itemOpacity: 1,
                    },
                  },
                ],
              },
            ]
          : undefined
      }
    />
  );
};

export default GeographyChart;
