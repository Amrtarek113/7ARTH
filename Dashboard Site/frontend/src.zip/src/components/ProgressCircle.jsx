import { Box, useTheme } from "@mui/material";
import { tokens } from "../theme";

const ProgressCircle = ({ value = 0, size = "40" }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  
  // Calculate progress as a percentage of value out of a max of 10
  const maxValue = 10; // Arbitrary max value for scaling
  const progress = value / maxValue; // E.g., 1 / 10 = 0.1 (10%)
  const angle = progress * 360;

  return (
    <Box
      sx={{
        background: `radial-gradient(${colors.primary[400]} 55%, transparent 56%),
            conic-gradient(transparent 0deg ${angle}deg, ${colors.blueAccent[500]} ${angle}deg 360deg),
            ${colors.greenAccent[500]}`,
        borderRadius: "50%",
        width: `${size}px`,
        height: `${size}px`,
      }}
    />
  );
};

export default ProgressCircle;