import React, { useState, useEffect } from 'react';
import { Box, Typography, useTheme } from '@mui/material';
import { tokens } from '../../theme';
import axios from 'axios';
import Header from '../../components/Header';
import { useNavigate } from 'react-router-dom';

const DoS = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const API_URL = 'http://localhost:5000/api';
  const navigate = useNavigate();

  const [metrics, setMetrics] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          console.error('No token found in localStorage');
          navigate('/login');
          return;
        }
        const response = await axios.get(`${API_URL}/metrics`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setMetrics(response.data.data);
      } catch (error) {
        console.error('Error fetching metrics:', error.response?.data || error.message);
        if (error.response && error.response.status === 401) {
          localStorage.removeItem('token');
          navigate('/login');
        }
      }
    };
    fetchData();
  }, [navigate]);

  if (!metrics) {
    return (
      <Box m="20px" textAlign="center" color={colors.grey[100]}>
        Loading DoS data...
      </Box>
    );
  }

  const dosAttacks = metrics.dos_attacks || { current: 0 };
  const incidents = [];
  if (dosAttacks.current > 0) {
    for (let i = 0; i < dosAttacks.current; i++) {
      incidents.push({
        id: `dos-${i + 1}`,
        type: 'DoS',
        detail: 'Denial of Service attack',
        date: new Date(Date.now() - Math.random() * 10000000000).toISOString().slice(0, 10),
        confidence: Math.random() * 0.5 + 0.5,
        threat: `Threat Level ${Math.floor(Math.random() * 5) + 1}`,
      });
    }
  }

  return (
    <Box m="20px">
      <Header title="DOS DETECTION" subtitle="Monitor Denial of Service Attacks" />
      <Box mb="40px">
        <Box mb="20px">
          <Typography variant="h5" color={colors.grey[100]} fontWeight="600" mb="10px">
            DoS Statistics
          </Typography>
          <Typography variant="h6" color={colors.grey[100]}>
            DoS: {dosAttacks.current} occurrence(s)
          </Typography>
        </Box>
        <Box>
          <Typography variant="h5" color={colors.grey[100]} fontWeight="600" mb="10px">
            DoS Incidents
          </Typography>
          {incidents.map((incident, i) => (
            <Box
              key={`${incident.id}-${i}`}
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              borderBottom={`4px solid ${colors.primary[500]}`}
              p="15px"
              backgroundColor={colors.primary[400]}
            >
              <Box>
                <Typography color={colors.greenAccent[500]} variant="h5" fontWeight="600">
                  {incident.type}: {incident.detail}
                </Typography>
                <Typography color={colors.grey[100]}>
                  {incident.date} (Confidence: {(incident.confidence * 100).toFixed(2)}%)
                </Typography>
              </Box>
              <Box backgroundColor={colors.greenAccent[500]} p="5px 10px" borderRadius="4px">
                {incident.threat}
              </Box>
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default DoS;