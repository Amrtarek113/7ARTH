import React, { useState, useEffect } from 'react';
import { Box, useTheme } from '@mui/material';
import { tokens } from '../../theme';
import axios from 'axios';
import BarChart from '../../components/BarChart';
import GeographyChart from '../../components/GeographyChart';
import LineChart from '../../components/LineChart';
import PieChart from '../../components/PieChart';
import Header from '../../components/Header';
import StatBox from '../../components/StatBox';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const Dashboard = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [metrics, setMetrics] = useState(null);
  const [timelineData, setTimelineData] = useState(null);
  const navigate = useNavigate(); // Initialize navigate

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        console.log('Token:', token); // Debug token
        if (!token) {
          console.error('No token found in localStorage');
          navigate('/login'); // Redirect to login if no token
          return;
        }
        const [metricsRes, timelineRes] = await Promise.all([
          axios.get('http://localhost:5000/api/metrics', { headers: { Authorization: `Bearer ${token}` } }),
          axios.get('http://localhost:5000/api/security-events-timeline', { headers: { Authorization: `Bearer ${token}` } }),
        ]);
        setMetrics(metricsRes.data.data);
        setTimelineData(timelineRes.data.data);
      } catch (error) {
        console.error('Error fetching dashboard data:', error.response?.data || error.message);
        if (error.response && error.response.status === 401) {
          localStorage.removeItem('token'); // Clear expired token
          navigate('/login'); // Redirect to login on 401
        }
      }
    };
    fetchData();
  }, [navigate]); // Add navigate to dependency array

  if (!metrics || !timelineData) {
    return (
      <Box m="20px" textAlign="center" color={colors.grey[100]}>
        Loading dashboard data...
      </Box>
    );
  }

  return (
    <Box m="20px">
      <Header title="DASHBOARD" subtitle="Welcome to your dashboard" />
      <Box
        display="grid"
        gridTemplateColumns="repeat(12, 1fr)"
        gridAutoRows="140px"
        gap="20px"
      >
        <Box gridColumn="span 3" backgroundColor={colors.primary[400]} display="flex" alignItems="center" justifyContent="center">
          <StatBox title={metrics.malicious_urls.current.toString()} subtitle="Malicious URLs" progress="0.5" increase={`+${metrics.malicious_urls.change}%`} />
        </Box>
        <Box gridColumn="span 3" backgroundColor={colors.primary[400]} display="flex" alignItems="center" justifyContent="center">
          <StatBox title={metrics.iot_attacks.current.toString()} subtitle="IoT Attacks" progress="0.75" increase={`+${metrics.iot_attacks.change}%`} />
        </Box>
        <Box gridColumn="span 3" backgroundColor={colors.primary[400]} display="flex" alignItems="center" justifyContent="center">
          <StatBox title={metrics.ransomware_incidents.current.toString()} subtitle="Ransomware" progress="0.3" increase={`+${metrics.ransomware_incidents.change}%`} />
        </Box>
        <Box gridColumn="span 3" backgroundColor={colors.primary[400]} display="flex" alignItems="center" justifyContent="center">
          <StatBox title={metrics.total_threats.current.toString()} subtitle="Total Threats" progress="0.8" increase={`+${metrics.total_threats.change}%`} />
        </Box>
        <Box gridColumn="span 6" gridRow="span 2" backgroundColor={colors.primary[400]}>
          <BarChart isDashboard={true} metrics={metrics} />
        </Box>
        <Box gridColumn="span 6" gridRow="span 2" backgroundColor={colors.primary[400]}>
          <PieChart timelineData={timelineData} />
        </Box>
        <Box gridColumn="span 6" gridRow="span 2" backgroundColor={colors.primary[400]}>
          <LineChart isDashboard={true} timelineData={timelineData} />
        </Box>
        <Box gridColumn="span 6" gridRow="span 2" backgroundColor={colors.primary[400]}>
          <GeographyChart isDashboard={true} metrics={metrics} />
        </Box>
      </Box>
    </Box>
  );
};

export default Dashboard;