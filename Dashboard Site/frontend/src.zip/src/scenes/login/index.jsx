import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { TextField, Button, Typography, Container, Box, useTheme } from '@mui/material';
import { tokens } from '../../theme';

const Login = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/login', {
        username,
        password,
      });
      if (response.data.status === 'success') {
        localStorage.setItem('token', response.data.data.access_token);
        navigate('/');
      } else {
        setError(response.data.message || 'Login failed');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please try again.');
    }
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 8 }}>
      <Box
        sx={{
          backgroundColor: colors.primary[400],
          p: 4,
          borderRadius: '8px',
          boxShadow: `0 4px 8px ${colors.primary[500]}`,
        }}
      >
        <Typography
          variant="h4"
          gutterBottom
          color={colors.grey[100]}
          fontWeight="bold"
          align="center"
        >
          Login
        </Typography>
        <form onSubmit={handleSubmit}>
          <TextField
            label="Username"
            fullWidth
            margin="normal"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            variant="outlined"
            InputLabelProps={{ style: { color: colors.grey[100] } }}
            InputProps={{
              style: { color: colors.grey[100], backgroundColor: colors.primary[500] },
            }}
          />
          <TextField
            label="Password"
            type="password"
            fullWidth
            margin="normal"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            variant="outlined"
            InputLabelProps={{ style: { color: colors.grey[100] } }}
            InputProps={{
              style: { color: colors.grey[100], backgroundColor: colors.primary[500] },
            }}
          />
          <Button
            type="submit"
            fullWidth
            sx={{
              backgroundColor: colors.blueAccent[700],
              color: colors.grey[100],
              fontSize: '14px',
              fontWeight: 'bold',
              padding: '10px 20px',
              mt: 2,
              '&:hover': { backgroundColor: colors.blueAccent[800] },
            }}
          >
            Login
          </Button>
          {error && (
            <Typography
              color="error"
              sx={{ mt: 2, textAlign: 'center' }}
            >
              {error}
            </Typography>
          )}
        </form>
      </Box>
    </Container>
  );
};

export default Login;